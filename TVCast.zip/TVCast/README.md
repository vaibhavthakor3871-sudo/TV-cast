# TV Cast (Android)

Phone ki video ko seedha TV pe cast karta hai. Screen mirroring nahi hai, isliye original quality + audio aur smooth seek milta hai.

## Kaise kaam karta hai
- Phone pe chhota HTTP server chalta hai jo video file ko jaisa hai waisa serve karta hai (Range support, koi re-encoding nahi).
- TV khud us URL se video kheech ke play karta hai. Phone busy ho ya screen off ho, playback chalta rehta hai (foreground service + WiFi lock).
- **Google Cast**: Chromecast, Google TV, Android TV, Airtel Xstream Box, Tata Play Binge (Cast icon se).
- **DLNA**: Samsung / LG / Mi aur dusre smart TV (DLNA TV button se).

## Build karna (Android Studio)
1. Latest Android Studio install karo.
2. `File > Open` se is `TVCast` folder ko kholo, Gradle sync hone do (internet chahiye).
3. Phone pe Developer options > USB debugging on karo, phone connect karo, Run dabao.
4. APK chahiye to `Build > Build APK(s)`.

## Use karna
1. Phone aur TV **same WiFi** pe (5 GHz best).
2. Cast icon dabao ya "DLNA TV" dabao, TV chuno.
3. "Video chuno" se movie select karo. Play start ho jayega.
4. Volume TV remote se. Band karne ke liye Stop ya notification ka "Band karo".

## Best quality ke tips
- **MP4 (H.264 + AAC)** sabse safe format hai, har TV pe chalta hai.
- Cast devices pe MKV, HEVC (H.265), AC3/DTS audio kuch models pe nahi chalta. Video chale par audio na aaye to usually audio codec ki wajah hoti hai.
- DLNA TV ka support TV ke brand pe depend karta hai. Agar ek TV pe na chale, MP4 file try karo.

## Notes
- targetSdk 35 rakha hai. Android 17 ka local network permission naye targetSdk (37) ke liye hota hai, to isse badalna ho to `ACCESS_LOCAL_NETWORK` permission flow add karni padegi.
- App band karke wapas kholne pe DLNA TV control dobara select karna padta hai (TV pe video chalta rehta hai).
