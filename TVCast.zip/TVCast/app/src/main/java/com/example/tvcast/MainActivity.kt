package com.example.tvcast

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.View
import android.webkit.MimeTypeMap
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.mediarouter.app.MediaRouteButton
import com.google.android.gms.cast.framework.CastButtonFactory
import com.google.android.gms.cast.framework.CastContext
import com.google.android.gms.cast.framework.CastSession
import com.google.android.gms.cast.framework.SessionManagerListener
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private var castContext: CastContext? = null
    private var target: TvTarget? = null

    private var mediaUrl: String? = null
    private var title = ""
    private var mime = "video/mp4"
    private var pendingLoad = false
    private var lastPlaying = true
    private var seeking = false

    private val ui = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    private lateinit var txtStatus: TextView
    private lateinit var txtFile: TextView
    private lateinit var txtTime: TextView
    private lateinit var seek: SeekBar
    private lateinit var btnPlayPause: Button

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) onVideoPicked(uri)
    }
    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    private val sessionListener = object : SessionManagerListener<CastSession> {
        override fun onSessionStarted(session: CastSession, sessionId: String) = onCastConnected(session)
        override fun onSessionResumed(session: CastSession, wasSuspended: Boolean) = onCastConnected(session)
        override fun onSessionEnded(session: CastSession, error: Int) {
            if (target is GoogleCastTarget) setTarget(null)
        }
        override fun onSessionStarting(session: CastSession) {}
        override fun onSessionStartFailed(session: CastSession, error: Int) {
            setStatus("Cast connect nahi hua. Dobara try karo.")
        }
        override fun onSessionEnding(session: CastSession) {}
        override fun onSessionResuming(session: CastSession, sessionId: String) {}
        override fun onSessionResumeFailed(session: CastSession, error: Int) {}
        override fun onSessionSuspended(session: CastSession, reason: Int) {}
    }

    private val ticker = object : Runnable {
        override fun run() {
            target?.poll { pos, dur, playing ->
                lastPlaying = playing
                updatePlayButton()
                if (!seeking) {
                    seek.max = dur.coerceAtLeast(0L).toInt()
                    seek.progress = pos.coerceAtLeast(0L).toInt()
                    txtTime.text = "${fmtTime(pos)} / ${fmtTime(dur)}"
                }
            }
            ui.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtStatus = findViewById(R.id.txtStatus)
        txtFile = findViewById(R.id.txtFile)
        txtTime = findViewById(R.id.txtTime)
        seek = findViewById(R.id.seek)
        btnPlayPause = findViewById(R.id.btnPlayPause)

        if (Build.VERSION.SDK_INT >= 33) {
            permLauncher.launch(
                arrayOf(Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.NEARBY_WIFI_DEVICES)
            )
        }

        try {
            val cc = CastContext.getSharedInstance(this)
            castContext = cc
            CastButtonFactory.setUpMediaRouteButton(
                applicationContext, findViewById<MediaRouteButton>(R.id.castButton)
            )
            cc.sessionManager.addSessionManagerListener(sessionListener, CastSession::class.java)
            cc.sessionManager.currentCastSession?.let { setTarget(GoogleCastTarget(it)) }
        } catch (e: Exception) {
            findViewById<View>(R.id.castButton).visibility = View.GONE
            setStatus("Google Cast nahi mila (Play Services chahiye). DLNA TV button use karo.")
        }

        findViewById<Button>(R.id.btnPick).setOnClickListener { picker.launch(arrayOf("video/*")) }
        findViewById<Button>(R.id.btnDlna).setOnClickListener { showDlnaPicker() }

        btnPlayPause.setOnClickListener {
            val t = target ?: return@setOnClickListener
            if (lastPlaying) t.pause() else t.play()
            lastPlaying = !lastPlaying
            updatePlayButton()
        }
        findViewById<Button>(R.id.btnStop).setOnClickListener {
            target?.stop()
            stopService(Intent(this, StreamService::class.java))
            setStatus("Stop kar diya.")
        }

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) txtTime.text = "${fmtTime(progress.toLong())} / ${fmtTime(sb.max.toLong())}"
            }
            override fun onStartTrackingTouch(sb: SeekBar) { seeking = true }
            override fun onStopTrackingTouch(sb: SeekBar) {
                seeking = false
                target?.seekTo(sb.progress.toLong())
            }
        })
    }

    override fun onResume() {
        super.onResume()
        ui.post(ticker)
    }

    override fun onPause() {
        ui.removeCallbacks(ticker)
        super.onPause()
    }

    override fun onDestroy() {
        castContext?.sessionManager?.removeSessionManagerListener(sessionListener, CastSession::class.java)
        target?.release()
        super.onDestroy()
    }

    // ---------------- targets ----------------

    private fun onCastConnected(session: CastSession) = setTarget(GoogleCastTarget(session))

    private fun setTarget(new: TvTarget?) {
        val old = target
        if (old != null && old !== new) {
            if (!(old is GoogleCastTarget && new is GoogleCastTarget)) old.stop()
            old.release()
        }
        target = new
        if (new == null) {
            setStatus("TV disconnect ho gaya.")
            return
        }
        pendingLoad = mediaUrl != null
        setStatus("Connected: ${new.label}" + if (mediaUrl == null) "\nAb video chuno." else "")
        maybeLoad()
    }

    private fun showDlnaPicker() {
        setStatus("DLNA TV dhundh raha hu…")
        io.execute {
            val devices = Dlna.discover(this)
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                if (devices.isEmpty()) {
                    setStatus(
                        "Koi DLNA TV nahi mila. Phone aur TV same WiFi pe hon, " +
                                "aur TV mein DLNA / Screen Share / Media Renderer on ho."
                    )
                    return@runOnUiThread
                }
                AlertDialog.Builder(this)
                    .setTitle("TV chuno")
                    .setItems(devices.map { it.name }.toTypedArray()) { _, i ->
                        setTarget(DlnaTvTarget(devices[i]))
                    }
                    .show()
            }
        }
    }

    // ---------------- video ----------------

    private fun onVideoPicked(uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
        }
        title = queryName(uri)
        val ext = title.substringAfterLast('.', "").lowercase()
        mime = contentResolver.getType(uri)?.takeIf { it.startsWith("video/") }
            ?: MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
                    ?: "video/mp4"
        txtFile.text = title
        setStatus("Video ready kar raha hu…")

        ContextCompat.startForegroundService(this, Intent(this, StreamService::class.java))

        io.execute {
            try {
                val ip = NetUtil.localIpv4() ?: throw IllegalStateException("WiFi se connect nahi ho")
                MediaServer.ensureStarted(this).setMedia(uri, mime)
                val fileExt = when (mime) {
                    "video/x-matroska" -> "mkv"
                    "video/quicktime" -> "mov"
                    else -> mime.substringAfter('/').ifEmpty { "mp4" }
                }
                val url = "http://$ip:${MediaServer.PORT}/video.$fileExt"
                runOnUiThread {
                    mediaUrl = url
                    pendingLoad = true
                    maybeLoad()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show()
                    setStatus("Error: ${e.message}")
                }
            }
        }
    }

    private fun maybeLoad() {
        val t = target
        val url = mediaUrl
        if (t == null) {
            if (url != null) setStatus("Video ready. Ab upar se TV chuno (Cast icon ya DLNA TV).")
            return
        }
        if (url != null && pendingLoad) {
            pendingLoad = false
            t.load(url, mime, title)
            lastPlaying = true
            updatePlayButton()
            setStatus("${t.label}\nPlay ho raha hai: $title")
        }
    }

    private fun queryName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0) return c.getString(i) ?: "video"
            }
        }
        return "video"
    }

    private fun setStatus(s: String) { txtStatus.text = s }

    private fun updatePlayButton() { btnPlayPause.text = if (lastPlaying) "Pause" else "Play" }
}
