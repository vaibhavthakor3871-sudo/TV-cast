package com.example.tvcast

import java.net.Inet4Address
import java.net.NetworkInterface

object NetUtil {
    /** The phone's LAN IPv4 (Wi-Fi or hotspot). */
    fun localIpv4(): String? {
        val ifaces = NetworkInterface.getNetworkInterfaces()?.toList() ?: return null
        val found = ifaces
            .filter { it.isUp && !it.isLoopback }
            .flatMap { nif ->
                nif.inetAddresses.toList()
                    .filterIsInstance<Inet4Address>()
                    .filter { it.isSiteLocalAddress }
                    .mapNotNull { a -> a.hostAddress?.let { nif.name to it } }
            }
        return (found.firstOrNull { it.first.startsWith("wlan") || it.first.startsWith("swlan") || it.first.startsWith("ap") }
            ?: found.firstOrNull())?.second
    }
}

fun fmtTime(ms: Long): String {
    val s = (if (ms < 0) 0 else ms) / 1000
    return String.format("%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
}
