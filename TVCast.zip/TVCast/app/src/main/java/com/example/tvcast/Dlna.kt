package com.example.tvcast

import android.content.Context
import android.net.wifi.WifiManager
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.net.URL

data class DlnaDevice(val name: String, val controlUrl: String)

/** Minimal UPnP/DLNA client: SSDP discovery + AVTransport control. All calls are blocking. */
object Dlna {
    private const val AVT = "urn:schemas-upnp-org:service:AVTransport:1"

    fun discover(context: Context, timeoutMs: Int = 4000): List<DlnaDevice> {
        val wifi = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val lock = wifi.createMulticastLock("tvcast-ssdp").apply {
            setReferenceCounted(false)
            acquire()
        }
        val locations = linkedSetOf<String>()
        try {
            DatagramSocket().use { socket ->
                socket.soTimeout = 800
                val msg = ("M-SEARCH * HTTP/1.1\r\n" +
                        "HOST: 239.255.255.250:1900\r\n" +
                        "MAN: \"ssdp:discover\"\r\n" +
                        "MX: 2\r\n" +
                        "ST: $AVT\r\n\r\n").toByteArray()
                val group = InetAddress.getByName("239.255.255.250")
                repeat(2) { socket.send(DatagramPacket(msg, msg.size, group, 1900)) }
                val end = System.currentTimeMillis() + timeoutMs
                val buf = ByteArray(2048)
                val locRegex = Regex("(?im)^location:\\s*(.+)$")
                while (System.currentTimeMillis() < end) {
                    try {
                        val p = DatagramPacket(buf, buf.size)
                        socket.receive(p)
                        val text = String(p.data, 0, p.length)
                        locRegex.find(text)?.groupValues?.get(1)?.trim()?.let { locations.add(it) }
                    } catch (_: SocketTimeoutException) {
                    }
                }
            }
        } catch (_: Exception) {
        } finally {
            try { lock.release() } catch (_: Exception) {}
        }
        return locations.mapNotNull { describe(it) }.distinctBy { it.controlUrl }
    }

    private fun describe(location: String): DlnaDevice? {
        return try {
            val xml = httpGet(location)
            val name = Regex("<friendlyName>(.*?)</friendlyName>", RegexOption.DOT_MATCHES_ALL)
                .find(xml)?.groupValues?.get(1)?.trim()?.replace("&amp;", "&") ?: "TV"
            val service = Regex("<service>(.*?)</service>", RegexOption.DOT_MATCHES_ALL)
                .findAll(xml).map { it.groupValues[1] }
                .firstOrNull { it.contains("AVTransport") } ?: return null
            val ctrl = Regex("<controlURL>(.*?)</controlURL>", RegexOption.DOT_MATCHES_ALL)
                .find(service)?.groupValues?.get(1)?.trim() ?: return null
            DlnaDevice(name, URL(URL(location), ctrl).toString())
        } catch (e: Exception) {
            null
        }
    }

    private fun httpGet(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 3000
        c.readTimeout = 3000
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    // ---- AVTransport actions ----

    fun setUri(d: DlnaDevice, url: String, mime: String, title: String): Boolean {
        val didl = "<DIDL-Lite xmlns=\"urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/\" " +
                "xmlns:dc=\"http://purl.org/dc/elements/1.1/\" " +
                "xmlns:upnp=\"urn:schemas-upnp-org:metadata-1-0/upnp/\">" +
                "<item id=\"0\" parentID=\"-1\" restricted=\"1\">" +
                "<dc:title>${esc(title)}</dc:title>" +
                "<upnp:class>object.item.videoItem</upnp:class>" +
                "<res protocolInfo=\"http-get:*:$mime:DLNA.ORG_OP=01;DLNA.ORG_CI=0;DLNA.ORG_FLAGS=01700000000000000000000000000000\">${esc(url)}</res>" +
                "</item></DIDL-Lite>"
        return soap(
            d, "SetAVTransportURI",
            "<CurrentURI>${esc(url)}</CurrentURI><CurrentURIMetaData>${esc(didl)}</CurrentURIMetaData>"
        ) != null
    }

    fun play(d: DlnaDevice): Boolean = soap(d, "Play", "<Speed>1</Speed>") != null
    fun pause(d: DlnaDevice): Boolean = soap(d, "Pause", "") != null
    fun stop(d: DlnaDevice): Boolean = soap(d, "Stop", "") != null
    fun seek(d: DlnaDevice, ms: Long): Boolean =
        soap(d, "Seek", "<Unit>REL_TIME</Unit><Target>${hms(ms)}</Target>") != null

    /** Returns (position, duration) in ms, or null if the TV did not answer. */
    fun position(d: DlnaDevice): Pair<Long, Long>? {
        val r = soap(d, "GetPositionInfo", "") ?: return null
        return parseHms(tag(r, "RelTime")) to parseHms(tag(r, "TrackDuration"))
    }

    fun isPlaying(d: DlnaDevice): Boolean? {
        val r = soap(d, "GetTransportInfo", "") ?: return null
        return tag(r, "CurrentTransportState") == "PLAYING"
    }

    // ---- helpers ----

    private fun soap(d: DlnaDevice, action: String, args: String): String? {
        return try {
            val body = "<?xml version=\"1.0\" encoding=\"utf-8\"?>" +
                    "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" " +
                    "s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><s:Body>" +
                    "<u:$action xmlns:u=\"$AVT\"><InstanceID>0</InstanceID>$args</u:$action>" +
                    "</s:Body></s:Envelope>"
            val c = URL(d.controlUrl).openConnection() as HttpURLConnection
            c.connectTimeout = 3000
            c.readTimeout = 5000
            c.requestMethod = "POST"
            c.doOutput = true
            c.setRequestProperty("Content-Type", "text/xml; charset=\"utf-8\"")
            c.setRequestProperty("SOAPACTION", "\"$AVT#$action\"")
            c.outputStream.use { it.write(body.toByteArray()) }
            if (c.responseCode in 200..299) c.inputStream.bufferedReader().use { it.readText() } else null
        } catch (e: Exception) {
            null
        }
    }

    private fun tag(xml: String, t: String): String? =
        Regex("<$t>(.*?)</$t>", RegexOption.DOT_MATCHES_ALL).find(xml)?.groupValues?.get(1)?.trim()

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        .replace("\"", "&quot;").replace("'", "&apos;")

    private fun hms(ms: Long): String {
        val s = ms / 1000
        return String.format("%d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
    }

    private fun parseHms(v: String?): Long {
        if (v == null) return 0L
        val parts = v.substringBefore('.').split(":")
        if (parts.size != 3) return 0L
        val h = parts[0].toLongOrNull() ?: return 0L
        val m = parts[1].toLongOrNull() ?: return 0L
        val s = parts[2].toLongOrNull() ?: return 0L
        return (h * 3600 + m * 60 + s) * 1000
    }
}
