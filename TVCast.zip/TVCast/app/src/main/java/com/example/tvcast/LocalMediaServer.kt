package com.example.tvcast

import android.content.Context
import android.net.Uri
import android.os.ParcelFileDescriptor
import fi.iki.elonen.NanoHTTPD
import java.io.InputStream

/**
 * Tiny HTTP server that streams the picked video file straight from the phone.
 * Supports HTTP Range requests, so seeking and buffering on the TV are instant
 * and the original file is served as-is (no re-encoding = original quality + audio).
 */
class LocalMediaServer(private val context: Context, port: Int) : NanoHTTPD(port) {

    @Volatile private var uri: Uri? = null
    @Volatile private var mime: String = "video/mp4"

    fun setMedia(uri: Uri, mime: String) {
        this.uri = uri
        this.mime = mime
    }

    override fun serve(session: NanoHTTPD.IHTTPSession): NanoHTTPD.Response {
        val u = uri ?: return text(NanoHTTPD.Response.Status.NOT_FOUND, "No media selected")
        val pfd: ParcelFileDescriptor = try {
            context.contentResolver.openFileDescriptor(u, "r")
        } catch (e: Exception) {
            null
        } ?: return text(NanoHTTPD.Response.Status.INTERNAL_ERROR, "Cannot open file")

        val total = pfd.statSize
        if (total <= 0) {
            pfd.close()
            return text(NanoHTTPD.Response.Status.INTERNAL_ERROR, "Unknown file size")
        }

        var start = 0L
        var end = total - 1
        var partial = false
        val range = session.headers["range"]
        if (range != null && range.startsWith("bytes=")) {
            val spec = range.removePrefix("bytes=").substringBefore(",").trim()
            val dash = spec.indexOf('-')
            if (dash >= 0) {
                val a = spec.substring(0, dash)
                val b = spec.substring(dash + 1)
                if (a.isEmpty()) {
                    // suffix range: last N bytes
                    val n = b.toLongOrNull()
                    if (n != null) start = maxOf(0L, total - n)
                } else {
                    start = a.toLongOrNull() ?: 0L
                    if (b.isNotEmpty()) end = minOf(b.toLongOrNull() ?: end, total - 1)
                }
                partial = true
            }
        }

        if (start >= total || start > end) {
            pfd.close()
            val r = text(NanoHTTPD.Response.Status.REQUEST_RANGE_NOT_SATISFIABLE, "")
            r.addHeader("Content-Range", "bytes */$total")
            return r
        }

        val length = end - start + 1
        val status = if (partial) NanoHTTPD.Response.Status.PARTIAL_CONTENT else NanoHTTPD.Response.Status.OK
        val res = NanoHTTPD.newFixedLengthResponse(status, mime, RangeStream(pfd, start, length), length)
        res.addHeader("Accept-Ranges", "bytes")
        res.addHeader("Access-Control-Allow-Origin", "*")
        res.addHeader("transferMode.dlna.org", "Streaming")
        res.addHeader("contentFeatures.dlna.org", "DLNA.ORG_OP=01;DLNA.ORG_CI=0;DLNA.ORG_FLAGS=01700000000000000000000000000000")
        if (partial) res.addHeader("Content-Range", "bytes $start-$end/$total")
        return res
    }

    private fun text(status: NanoHTTPD.Response.IStatus, msg: String): NanoHTTPD.Response =
        NanoHTTPD.newFixedLengthResponse(status, NanoHTTPD.MIME_PLAINTEXT, msg)

    /** Reads [remaining] bytes starting at [start]; closes the file descriptor when done. */
    private class RangeStream(pfd: ParcelFileDescriptor, start: Long, private var remaining: Long) : InputStream() {
        private val fis = ParcelFileDescriptor.AutoCloseInputStream(pfd)

        init {
            fis.channel.position(start)
        }

        override fun read(): Int {
            if (remaining <= 0) return -1
            val b = fis.read()
            if (b >= 0) remaining--
            return b
        }

        override fun read(b: ByteArray, off: Int, len: Int): Int {
            if (remaining <= 0) return -1
            val n = fis.read(b, off, minOf(len.toLong(), remaining).toInt())
            if (n > 0) remaining -= n
            return n
        }

        override fun available(): Int = minOf(remaining, Int.MAX_VALUE.toLong()).toInt()

        override fun close() {
            try { fis.close() } catch (_: Exception) {}
        }
    }
}

object MediaServer {
    const val PORT = 8765
    private var server: LocalMediaServer? = null

    @Synchronized
    fun ensureStarted(context: Context): LocalMediaServer {
        server?.let { if (it.isAlive) return it }
        val s = LocalMediaServer(context.applicationContext, PORT)
        s.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false)
        server = s
        return s
    }

    @Synchronized
    fun stop() {
        server?.stop()
        server = null
    }
}
