package com.example.tvcast

import android.os.Handler
import android.os.Looper
import com.google.android.gms.cast.MediaInfo
import com.google.android.gms.cast.MediaLoadRequestData
import com.google.android.gms.cast.MediaMetadata
import com.google.android.gms.cast.MediaSeekOptions
import com.google.android.gms.cast.framework.CastSession
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/** Anything the video can be sent to: a Google Cast device or a DLNA renderer. */
interface TvTarget {
    val label: String
    fun load(url: String, mime: String, title: String)
    fun play()
    fun pause()
    fun stop()
    fun seekTo(ms: Long)

    /** Always calls [onResult] on the main thread. */
    fun poll(onResult: (positionMs: Long, durationMs: Long, playing: Boolean) -> Unit)

    fun release() {}
}

class GoogleCastTarget(private val session: CastSession) : TvTarget {
    override val label: String
        get() = "Cast: " + (session.castDevice?.friendlyName ?: "TV")

    override fun load(url: String, mime: String, title: String) {
        val meta = MediaMetadata(MediaMetadata.MEDIA_TYPE_MOVIE)
        meta.putString(MediaMetadata.KEY_TITLE, title)
        val info = MediaInfo.Builder(url)
            .setStreamType(MediaInfo.STREAM_TYPE_BUFFERED)
            .setContentType(mime)
            .setMetadata(meta)
            .build()
        session.remoteMediaClient?.load(
            MediaLoadRequestData.Builder().setMediaInfo(info).setAutoplay(true).build()
        )
    }

    override fun play() { session.remoteMediaClient?.play() }
    override fun pause() { session.remoteMediaClient?.pause() }
    override fun stop() { session.remoteMediaClient?.stop() }
    override fun seekTo(ms: Long) {
        session.remoteMediaClient?.seek(MediaSeekOptions.Builder().setPosition(ms).build())
    }

    override fun poll(onResult: (Long, Long, Boolean) -> Unit) {
        val c = session.remoteMediaClient ?: return
        onResult(c.approximateStreamPosition, c.streamDuration, c.isPlaying)
    }
}

class DlnaTvTarget(private val dev: DlnaDevice) : TvTarget {
    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val busy = AtomicBoolean(false)

    override val label: String get() = "DLNA: ${dev.name}"

    override fun load(url: String, mime: String, title: String) {
        io.execute {
            Dlna.stop(dev) // some TVs refuse a new URI while playing
            if (Dlna.setUri(dev, url, mime, title)) {
                repeat(4) {
                    if (Dlna.play(dev)) return@execute
                    Thread.sleep(700)
                }
            }
        }
    }

    override fun play() { io.execute { Dlna.play(dev) } }
    override fun pause() { io.execute { Dlna.pause(dev) } }
    override fun stop() { io.execute { Dlna.stop(dev) } }
    override fun seekTo(ms: Long) { io.execute { Dlna.seek(dev, ms) } }

    override fun poll(onResult: (Long, Long, Boolean) -> Unit) {
        if (!busy.compareAndSet(false, true)) return
        io.execute {
            try {
                val pos = Dlna.position(dev)
                val playing = Dlna.isPlaying(dev)
                if (pos != null) main.post { onResult(pos.first, pos.second, playing ?: false) }
            } finally {
                busy.set(false)
            }
        }
    }

    override fun release() { io.shutdown() }
}
